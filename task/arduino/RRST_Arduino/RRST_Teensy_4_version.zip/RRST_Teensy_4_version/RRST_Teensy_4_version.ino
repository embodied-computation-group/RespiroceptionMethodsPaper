


#include "LocalMenuCmd.h" // Local fixed version wrapper 
#include <teensystep4.h>


#define LedOnBoard 13

#define EndstopMaxPin 6
#define EndstopMinPin 7
#define EnablePin 8
#define DirPin 9
#define StepPin 10
#define STARTPOS 20000
#define ACCELERATION 10000
#define SPEED 14000


using namespace TS4; 

SerialMenuCmd myMmuCmd;
Stepper motor(StepPin, DirPin);  


uint8_t StepperStatus;
int32_t MaxPosition = 45000;       
uint8_t CalibrationStatus = 0;
int32_t CurrentPosition = 0;       
uint32_t Acceleration = ACCELERATION; 
uint32_t Speed = SPEED;               
uint16_t LedOnTime;
uint16_t LedOffTime;
uint32_t tEvent;
String Software;

long initial_homing = -300;


void LedInfoUserPanic(void);

/* CLI( Command Line Interface)================================================ */

tMenuCmdTxt txt1_EnableStepper[] = "e - enable stepper (normal mode)";
tMenuCmdTxt txt2_DisableStepper[] = "d - disable stepper";
tMenuCmdTxt txt3_Calibrate[] = "c - calibrate min & max";
tMenuCmdTxt txt4_Home[] = "h - home stepper";
tMenuCmdTxt txt5_SafeOperation[] = "o - Operate with in safemode";
tMenuCmdTxt txt6_AbsoluteMove[] = "a - move to absolute position";
tMenuCmdTxt txt7_Status[] = "s - status";
tMenuCmdTxt txt8_Menu[] = "m - menu";
tMenuCmdTxt txt9_Speed[] = "f - speed";
tMenuCmdTxt txt10_Acceleration[] = "g - acceleration";
tMenuCmdTxt txt_Prompt[] = "Valve";

void cmd1_EnableStepper(void);
void cmd2_DisableStepper(void);
void cmd3_Calibrate(void);
void cmd4_Home(void);
void cmd5_SafeOperation(void);
void cmd6_AbsoluteMove(void);
void cmd7_Status(void);
void cmd8_Menu(void);
void cmd9_Speed(void);
void cmd10_Acceleration(void);

stMenuCmd list[] = {
    {txt1_EnableStepper, 'e', cmd1_EnableStepper},
    {txt2_DisableStepper, 'd', cmd2_DisableStepper},
    {txt3_Calibrate, 'c', cmd3_Calibrate},
    {txt4_Home, 'h', cmd4_Home},
    {txt5_SafeOperation, 'o', cmd5_SafeOperation},
    {txt6_AbsoluteMove, 'a', cmd6_AbsoluteMove},  
    {txt7_Status, 's', cmd7_Status},  
    {txt8_Menu, 'm', cmd8_Menu},
    {txt9_Speed, 'f', cmd9_Speed},
    {txt10_Acceleration, 'g', cmd10_Acceleration}
};

#define NbCmds sizeof(list) / sizeof(stMenuCmd)

/* Functions Implementation =================================================== */

void setup()
{
  Serial.begin(115200);

  // Initialize TeensyStep4 backend
  TS4::begin(); 

  motor.setAcceleration(Acceleration)
       .setMaxSpeed(Speed);
  
  pinMode(EndstopMinPin, INPUT_PULLUP);
  pinMode(EndstopMaxPin, INPUT_PULLUP);
  pinMode(EnablePin, OUTPUT);
  pinMode(LedOnBoard, OUTPUT);
  digitalWrite(LedOnBoard, LOW);

  StepperStatus = 0;
  LedOnTime = 1000;
  LedOffTime = 1000;
  tEvent = 0;
  Software = "2026r5";

  if (myMmuCmd.begin(list, NbCmds, txt_Prompt) == false)
  {
    while (true) { LedInfoUserPanic(); }
  }

  myMmuCmd.ShowMenu();
  myMmuCmd.giveCmdPrompt();
}

void loop()
{
  uint8_t CmdCode = myMmuCmd.UserRequest();

  if (CmdCode != 0)
  {
    myMmuCmd.ExeCommand(CmdCode);
  }
  
  switch(StepperStatus)
  {
    case 0: 
      if(digitalRead(LedOnBoard) == true) digitalWrite(LedOnBoard, false);
      break;
    case 1: 
      if(digitalRead(LedOnBoard) == false) digitalWrite(LedOnBoard, true);
      break;
    case 2:
      if(millis() >= tEvent)
      {
        tEvent = millis() + (digitalRead(LedOnBoard) ? LedOffTime : LedOnTime);
        digitalWrite(LedOnBoard, !digitalRead(LedOnBoard));
      }
      break;
  }
}

void LedInfoUserPanic(void)
{
  digitalWrite(LedOnBoard, HIGH); delay(100);
  digitalWrite(LedOnBoard, LOW);  delay(100);
}

void cmd1_EnableStepper(void)
{
  StepperStatus = 1;  
  Serial.println(F("\nStepper enabled in normal mode\n"));
  digitalWrite(EnablePin, LOW);
  myMmuCmd.giveCmdPrompt();
}

void cmd2_DisableStepper(void)
{
  StepperStatus = 0;
  Serial.println(F("\nStepper disabled\n"));
  digitalWrite(EnablePin, HIGH);
  myMmuCmd.giveCmdPrompt();
}

void cmd3_Calibrate(void)
{
  Serial.println(F("\nStarting calibration..."));
  digitalWrite(EnablePin, LOW);
  
  motor.setMaxSpeed(Speed / 2); 
  motor.moveRelAsync(-100000);   
  
  while(motor.isMoving) {
    if(digitalRead(EndstopMinPin) == LOW) { 
      motor.stop();
      break;
    }
    yield();
  }
  
  motor.setPosition(0); 
  Serial.println(F("Min Endstop found. Position set to 0."));
  delay(500);

  motor.moveRelAsync(100000);
  
  while(motor.isMoving) {
    if(digitalRead(EndstopMaxPin) == LOW) { 
      motor.stop();
      break;
    }
    yield();
  }
  
  MaxPosition = motor.getPosition();
  CalibrationStatus = 1;
  
  motor.setMaxSpeed(Speed); 
  
  Serial.printf("Max Endstop found. Max Position: %d\n\n", MaxPosition);
  myMmuCmd.giveCmdPrompt();
}

void cmd4_Home(void)
{
  Serial.println(F("\nHoming to position 0..."));
  motor.moveAbs(0); 
  Serial.println(F("Homing completed.\n"));
  myMmuCmd.giveCmdPrompt();
}

void cmd5_SafeOperation(void)
{
  Serial.println(F("\nSafe mode verified. Soft limits active."));
  myMmuCmd.giveCmdPrompt();
}

void cmd6_AbsoluteMove(void)
{
  Serial.println(F("\nEnter absolute target position (steps):"));
  while(!Serial.available()) { yield(); }
  
  int32_t target = Serial.parseInt();
  
  if(CalibrationStatus == 1 && (target < 0 || target > MaxPosition)) {
    Serial.println(F("Error: Target out of calibrated bounds!"));
  } else {
    Serial.printf("Moving to absolute position: %d\n", target);
    motor.moveAbs(target);
    Serial.println(F("Move complete."));
  }
  myMmuCmd.giveCmdPrompt();
}

void cmd7_Status(void)
{
  CurrentPosition = motor.getPosition();
  Serial.println(F("\n--- SYSTEM STATUS ---"));
  Serial.printf("Software Version: %s\n", Software.c_str());
  Serial.printf("Current Position: %d steps\n", CurrentPosition);
  Serial.printf("Max Range Limit:  %d steps\n", MaxPosition);
  Serial.printf("Calibrated:       %s\n", CalibrationStatus ? "YES" : "NO");
  Serial.printf("Current Speed:    %d steps/s\n", Speed);
  Serial.printf("Acceleration:     %d steps/s²\n---\n", Acceleration);
  myMmuCmd.giveCmdPrompt();
}

void cmd8_Menu(void)
{
  Serial.println("");
  myMmuCmd.ShowMenu();
  myMmuCmd.giveCmdPrompt();
}

void cmd9_Speed(void)
{
  Serial.printf("\nCurrent speed is %d. Enter new max speed: \n", Speed);
  while(!Serial.available()) { yield(); }
  uint32_t newSpeed = Serial.parseInt();
  if(newSpeed > 0) {
    Speed = newSpeed;
    motor.setMaxSpeed(Speed);
    Serial.printf("Speed set to %d\n\n", Speed);
  }
  myMmuCmd.giveCmdPrompt();
}

void cmd10_Acceleration(void)
{
  Serial.printf("\nCurrent acceleration is %d. Enter new acceleration: \n", Acceleration);
  while(!Serial.available()) { yield(); }
  uint32_t newAccel = Serial.parseInt();
  if(newAccel > 0) {
    Acceleration = newAccel;
    motor.setAcceleration(Acceleration);
    Serial.printf("Acceleration set to %d\n\n", Acceleration);
  }
  myMmuCmd.giveCmdPrompt();
}
